from project.cat import Cat
from project.dog import Dog

c = Cat()
print(c.meow())
d = Dog()
print(d.bark())